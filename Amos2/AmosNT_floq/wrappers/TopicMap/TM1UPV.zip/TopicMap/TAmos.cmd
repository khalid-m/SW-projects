@echo off

java -ms64m -mx512m -cp "../../bin/javaamos.jar;classes;%AMOS_HOME%/bin/sward.jar;lib/tm4j-0.9.7.jar;lib/resolver.jar;lib/mango.jar;lib/commons-logging.jar" JavaAMOS TAmos.dmp 
