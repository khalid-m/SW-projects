@echo off

IF EXIST TAmos.dmp del TAmos.dmp /q

call env.cmd

pushd classes
java -classpath ".;%CLASSPATH%;classes;%AMOS_HOME%/bin/sward.jar"  JavaAMOS "%AMOS_HOME%/bin/amos2.dmp" ../src/mkdmp.amosql
popd classes
pause


