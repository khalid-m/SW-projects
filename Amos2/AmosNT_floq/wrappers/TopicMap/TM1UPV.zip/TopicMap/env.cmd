@echo off

call checkenv

set LIB=%AMOS_HOME%\wrappers\TopicMap\lib
set CLASSPATH=%LIB%\tm4j-0.9.7.jar;%LIB%\resolver.jar;%LIB%\mango.jar;%LIB%\commons-logging.jar;%CLASSPATH%
