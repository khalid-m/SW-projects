@echo off

call compile.cmd
call mkdmp.cmd

pushd classes
javaamos "../TAmos.dmp" ../test.amosql
popd
