	How to compile and run the Topic Map wrapper and RDF tripple mapper
	-----------------------------------------------------------------------


1. Compile the needed java code by 
   compile.cmd 

2. Generate Amos II database image for TMAmos by calling
   mkdmp.cmd

3. Run Tamos by calling
   TAmos.cmd  


4. In order a xtm file to be loaded call:

	loadXTM("hamlet.xtm");

The file "hamlet.xtm" can be used as an example.

The file exps.amosql contains examples of RDF queries in RDQL and SQL.

