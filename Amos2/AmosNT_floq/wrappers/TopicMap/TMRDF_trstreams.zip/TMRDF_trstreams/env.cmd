@echo off

call checkenv

set LIB=%AMOS_HOME%\wrappers\TopicMap\lib
set CLASSPATH=.;%JAVA_HOME%..\lib\tools.jar;%JAVA_HOME%..\lib\dt.jar;%AMOS_HOME%\bin\javaamos.jar;%LIB%\tm4j-0.9.7.jar;%LIB%\resolver.jar;%LIB%\mango.jar;%LIB%\commons-logging.jar;%CLASSPATH%
set PATH=%PATH%;%AMOS_HOME%\bin;%JAVA_HOME%