@echo off

IF EXIST TAmos.dmp del TAmos.dmp /q

call env.cmd

pushd classes
"%java_home%java" -classpath "%CLASSPATH%;%AMOS_HOME%/wrappers/rdf/classes;%AMOS_HOME%/wrappers/TopicMap/src/classes"  JavaAMOS "%AMOS_HOME%/bin/amos2.dmp" ../src/mkdmp.amosql
popd classes
pause