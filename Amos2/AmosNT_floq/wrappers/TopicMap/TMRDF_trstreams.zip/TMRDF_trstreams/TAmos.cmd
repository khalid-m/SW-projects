@echo off

call mkdmp.cmd
call compile.cmd
set CLASSPATH=%CLASSPATH%;%AMOS_HOME%wrappers\rdf\classes;%AMOS_HOME%wrappers\TopicMap\src\classes;%CLASSPATH%;%AMOS_HOME%/bin/RDFamos.jar;%JENA_HOME%/lib/jena.jar;%JENA_HOME%/lib/xercesImpl.jar;%JENA_HOME%/lib/icu4j.jar;%JENA_HOME%/lib/commons-logging.jar
pushd classes
javaamos "%AMOS_HOME%wrappers\TopicMap\TAmos.dmp"
popd

