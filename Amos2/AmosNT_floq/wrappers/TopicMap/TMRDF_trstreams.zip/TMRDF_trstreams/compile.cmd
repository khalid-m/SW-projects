@echo off

IF EXIST classes\*.class del classes\*.class /q

call env.cmd

"%java_home%javac" -classpath "%AMOS_HOME%/bin/javaamos.jar;%JENA_HOME%/lib/jena.jar;%JENA_HOME%/lib/;%JENA_HOME%/lib/xercesImpl.jar;%JENA_HOME%/lib/xmlAPIs.jar;%JENA_HOME%/lib/commons-logging.jar;%JENA_HOME%/lib/icu4j.jar" -d "%AMOS_HOME%wrappers\RDF\classes" %AMOS_HOME%wrappers\RDF\src\Java\AmosStmt.java
javac -classpath %AMOS_HOME%\bin\javaamos.jar;%LIB%\tm4j-0.9.7.jar;%LIB%\resolver.jar;%LIB%\mango.jar;%LIB%\commons-logging.jar  -d %AMOS_HOME%\wrappers\TopicMap\classes %AMOS_HOME%wrappers\TopicMap\src\TMWrapper.java
popd
