	How to compile and run Topic Map wrapper and tranformer to RDF triples
	-----------------------------------------------------------------------


1. Compile the needed java code by compile.cmd 

2. Generate Amos II database image for TMAmos by calling
   mkdmp.cmd

3. Run Tamos by calling
   TAmos.cmd  


In order to load an RDF schema for Topic Map one has to call

	loadRDFSchema("../TMRDF.xml");

The file TMRDF.xml contains one possible schema fro transformation from Topic Map to RDF.


Once the schema has been loaded, a xtm file is possible to be loaded by calling

	loadXTM("../hamlet.xtm");

The file hamlet.xtm can be used as an example.


The generated RDF triples can be seen by calling

	resT();

If one wants to study the different components of the loaded Topic Map in goovi, should call the function

	migrateRDF();

